﻿using System.ComponentModel;
using System.Configuration.Install;
using System.ServiceProcess;

namespace ConsumptionService.Service
{
    [RunInstaller(true)]
    public class ProjectInstaller : Installer
    {
        public ProjectInstaller()
        {
            var processInstaller = new ServiceProcessInstaller
            {
                Account = ServiceAccount.LocalSystem
            };

            var serviceInstaller = new ServiceInstaller
            {
                ServiceName = ConsumptionWindowsService.ServiceNameConst,
                DisplayName = "Consumption Service (BIL -> SAP)",
                Description = "Captura o consumo real de material no Simatic Batch (BIL) e envia B2MML ao SAP via DIS.",
                StartType = ServiceStartMode.Automatic
            };

            Installers.Add(processInstaller);
            Installers.Add(serviceInstaller);
        }
    }
}

