﻿using System.ServiceProcess;

namespace ConsumptionService.Service
{
    public class ConsumptionWindowsService : ServiceBase
    {
        public const string ServiceNameConst = "ConsumptionService";

        private readonly Worker _worker = new Worker();

        public ConsumptionWindowsService()
        {
            ServiceName = ServiceNameConst; 
            CanStop = true;
            CanShutdown = true;
            AutoLog = true;
        }

        protected override void OnStart(string[] args)
        {
            _worker.Start();
        }

        protected override void OnStop()
        {
            _worker.Stop();
        }

        protected override void OnShutdown()
        {
            _worker.Stop();
        }
    }
}

