﻿using System;
using System.Collections.Generic;

namespace ConsumptionService.Parsing
{
    public class BilMessage
    {
        public BilMessage()
        {
            Header = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            Body = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            Parameters = new List<BilParameter>();
        }

        public IDictionary<string, string> Header { get; private set; }

        public IDictionary<string, string> Body { get; private set; }

        public IList<BilParameter> Parameters { get; private set; }

        // ---- Header ----
        public string MessageId { get { return GetHeader("MessageId"); } }
        public string MessageType { get { return GetHeader("MessageType"); } }
        public string MessageAction { get { return GetHeader("MessageAction"); } }
        public string PCellName { get { return GetHeader("MessagePCellName"); } }

        // ---- Body (comuns) ----
        public string BatchHandle { get { return GetBody("BatchHandle"); } }
        public string BatchName { get { return GetBody("BatchName"); } }
        public string OrderName { get { return GetBody("OrderName"); } }
        public string OrderCategoryName { get { return GetBody("OrderCategoryName"); } }
        public string UnitName { get { return GetBody("UnitName"); } }

        public string RopContId { get { return GetBody("RopContId"); } }
        public string RupContId { get { return GetBody("RupContId"); } }
        public string PhaseName { get { return GetBody("PhaseName"); } }

        public int RopActivationCounter { get { return ParseUtil.ParseInt(GetBody("RopActivationCounter"), 1); } }
        public int PhaseActivationCounter { get { return ParseUtil.ParseInt(GetBody("PhaseActivationCounter"), 1); } }

        public string CurrentState { get { return GetBody("CurrentState"); } }
        public string OldState { get { return GetBody("OldState"); } }
        public string CurrentPhaseState { get { return GetBody("CurrentPhaseState"); } }

        public string ProductName { get { return GetBody("ProductName"); } }
        public string ProductCode { get { return GetBody("ProductCode"); } }
        public string RecipeProcedureName { get { return GetBody("RecipeProcedureName"); } }
        public decimal Quantity { get { return ParseUtil.ParseDecimal(GetBody("Quantity")); } }
        public string UomName { get { return GetBody("UomName"); } }

        public DateTime? NotificationTime { get { return ParseUtil.ParseDateTime(GetBody("NotificationTime")); } }

        public string GetHeader(string name)
        {
            string value;
            return Header.TryGetValue(name, out value) ? value : null;
        }

        public string GetBody(string name)
        {
            string value;
            return Body.TryGetValue(name, out value) ? value : null;
        }

        public BilParameter GetParameter(string parameterName)
        {
            if (string.IsNullOrEmpty(parameterName))
                return null;

            foreach (var p in Parameters)
            {
                if (string.Equals(p.ParameterName, parameterName, StringComparison.OrdinalIgnoreCase))
                    return p;
            }
            return null;
        }
    }
}

