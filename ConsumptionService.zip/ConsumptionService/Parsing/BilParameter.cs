﻿namespace ConsumptionService.Parsing
{
    public class BilParameter
    {
        public const string UsageInput = "BF_API_PARAMETERUSAGE_INPUT";
        public const string UsageOutput = "BF_API_PARAMETERUSAGE_OUTPUT";
        public const string UsageControlStrategy = "BF_API_PARAMETERUSAGE_CONTROLSTRATEGY";

        public string ParameterId { get; set; }
        public string ParameterName { get; set; }
        public string ContID { get; set; }
        public string TermID { get; set; }
        public string DataTypeName { get; set; }
        public string UomName { get; set; }
        public string SetPoint { get; set; }
        public string ActualValue { get; set; }
        public string LowValue { get; set; }
        public string HiValue { get; set; }
        public string MaterialId { get; set; }
        public string MaterialCode { get; set; }
        public string MaterialName { get; set; }
        public string ParameterUsage { get; set; }

        public bool IsInputMaterial
        {
            get
            {
                return !string.IsNullOrEmpty(ParameterUsage)
                    && string.Equals(ParameterUsage, UsageInput, System.StringComparison.OrdinalIgnoreCase);
            }
        }
    }
}

