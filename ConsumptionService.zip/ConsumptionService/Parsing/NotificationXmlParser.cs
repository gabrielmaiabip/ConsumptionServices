﻿using System;
using System.Xml.Linq;
using ConsumptionService.Logging;

namespace ConsumptionService.Parsing
{
    
    public static class NotificationXmlParser
    {
        public static BilMessage Parse(string xml)
        {
            if (string.IsNullOrWhiteSpace(xml))
                return null;

            XDocument doc;
            try
            {
                doc = XDocument.Parse(xml);
            }
            catch (Exception ex)
            {
                Log.Error(ex, "NotificationXmlParser.Parse - XML inválido");
                return null;
            }

            var messageEl = doc.Element("Message");
            if (messageEl == null)
                return null;

            var message = new BilMessage();

            var headerEl = messageEl.Element("Header");
            if (headerEl != null)
                CopyAttributes(headerEl, message.Header);

            var bodyEl = messageEl.Element("Body");
            if (bodyEl != null)
            {
                CopyAttributes(bodyEl, message.Body);

                var parametersEl = bodyEl.Element("Parameters");
                if (parametersEl != null)
                {
                    foreach (var paramEl in parametersEl.Elements("Parameter"))
                        message.Parameters.Add(ParseParameter(paramEl));
                }
            }

            return message;
        }

        private static BilParameter ParseParameter(XElement el)
        {
            return new BilParameter
            {
                ParameterId = Attr(el, "ParameterId"),
                ParameterName = Attr(el, "ParameterName"),
                ContID = Attr(el, "ContID"),
                TermID = Attr(el, "TermID"),
                DataTypeName = Attr(el, "DataTypeName"),
                UomName = Attr(el, "UomName"),
                SetPoint = Attr(el, "SetPoint"),
                ActualValue = Attr(el, "ActualValue"),
                LowValue = Attr(el, "LowValue"),
                HiValue = Attr(el, "HiValue"),
                MaterialId = Attr(el, "MaterialId"),
                MaterialCode = Attr(el, "MaterialCode"),
                MaterialName = Attr(el, "MaterialName"),
                ParameterUsage = Attr(el, "ParameterUsage")
            };
        }

        private static void CopyAttributes(XElement element, System.Collections.Generic.IDictionary<string, string> target)
        {
            foreach (var attr in element.Attributes())
                target[attr.Name.LocalName] = attr.Value;
        }

        private static string Attr(XElement element, string name)
        {
            if (element == null)
                return null;
            var attr = element.Attribute(name);
            return attr != null ? attr.Value : null;
        }
    }
}

