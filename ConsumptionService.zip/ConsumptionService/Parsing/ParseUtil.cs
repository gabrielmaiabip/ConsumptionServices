﻿using System;
using System.Globalization;

namespace ConsumptionService.Parsing
{
    public static class ParseUtil
    {
        public static decimal ParseDecimal(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return 0m;

            value = value.Trim();

            decimal result;
            if (decimal.TryParse(value, NumberStyles.Any, CultureInfo.InvariantCulture, out result))
                return result;

            var normalized = value.Replace(",", ".");
            if (decimal.TryParse(normalized, NumberStyles.Any, CultureInfo.InvariantCulture, out result))
                return result;

            return 0m;
        }

        public static int ParseInt(string value, int defaultValue)
        {
            if (string.IsNullOrWhiteSpace(value))
                return defaultValue;

            int result;
            return int.TryParse(value.Trim(), NumberStyles.Any, CultureInfo.InvariantCulture, out result)
                ? result
                : defaultValue;
        }

        public static DateTime? ParseDateTime(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return null;

            DateTime result;
            if (DateTime.TryParse(value.Trim(), CultureInfo.InvariantCulture,
                    DateTimeStyles.AdjustToUniversal | DateTimeStyles.AssumeUniversal, out result))
                return result;

            return null;
        }
    }
}

