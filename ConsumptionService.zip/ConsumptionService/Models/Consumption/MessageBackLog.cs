﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsumptionService.Models.Consumption
{
    /// Caixa de saída (Outbox): histórico do XML (B2MML) gerado e enviado ao SAP.
    /// Funciona como recibo e permite reenvio em caso de falha.
    /// Cada mensagem corresponde a um grupo de ROP (RopContId + ActivationCounter).

    public class MessageBacklog
    {
        public int MessageBacklogId { get; set; }
        public int BatchCorrelationId { get; set; }
        public int? ProductionOrderId { get; set; }

        public string RopContId { get; set; }
        public int ActivationCounter { get; set; }

        /// Chave única da mensagem — evita enviar o mesmo pacote duas vezes.
        public string BacklogKey { get; set; }

        /// XML completo (B2MML / PROCESS_MESS_UPLOAD) enviado ao SAP.
        public string PayloadXml { get; set; }
        public int ItemCount { get; set; }

        /// Pending, Sent ou Failed.
        public string Status { get; set; }
        public int AttemptCount { get; set; }
        public DateTime? SentAt { get; set; }
        public string ErrorMessage { get; set; }

        public BatchCorrelation BatchCorrelation { get; set; }
        public ProductionOrder ProductionOrder { get; set; }
    }
}
