﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsumptionService.Models.Consumption
{
    /// Tabela de mapeamento Material → Depósito (StorageLocation).
    /// Permite definir o PPPI_STORAGE_LOCATION por material.
    /// Materiais não mapeados usam o valor default configurado em App.config (DefaultStorageLocation).
    /// 
    public class MaterialStorageLocation
    {
        /// <summary>
        /// Código do material (ex: "79707754"). Chave primária.
        /// </summary>
        public string MaterialId { get; set; }

        /// <summary>
        /// Código do depósito SAP (ex: "2102").
        /// </summary>
        public string StorageLocation { get; set; }
    }
}
