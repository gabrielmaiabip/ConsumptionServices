﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsumptionService.Models.Consumption
{
    public class ProcessedNotification
    {
        public int ProcessedNotificationId { get; set; }

        public string SourceSystem { get; set; }
        public string NotificationId { get; set; }
        public string NotificationType { get; set; }

        /// Chave única da mensagem (ex: MessageId do Header). Índice UNIQUE.
        public string MessageIdempotencyKey { get; set; }

        public string BatchHandle { get; set; }
        public string OrderName { get; set; }
        public string RopContId { get; set; }

        /// PROCESSED, IGNORED ou ERROR.
        public string ProcessingStatus { get; set; }
        public DateTime ProcessedAt { get; set; }
    }
}
