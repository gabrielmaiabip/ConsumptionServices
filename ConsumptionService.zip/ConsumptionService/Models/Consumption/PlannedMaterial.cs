﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsumptionService.Models.Consumption
{
    /// Matéria-prima que o SAP planejou consumir na ordem (lista da receita / BOM).
    /// Representa a expectativa; o consumo real é registrado em ConsumptionBatchMovement.

    public class PlannedMaterial
    {
        public int PlannedMaterialId { get; set; }
        public int ProductionOrderId { get; set; }

        public string MaterialId { get; set; }
        public string MaterialDescription { get; set; }
        public decimal PlannedQuantity { get; set; }
        public string Uom { get; set; }

        /// Posição do material na receita (Bill of Materials).
        public string BomItem { get; set; }

        // Relacionamento com ProductionOrder (Muitos para 1)
        public ProductionOrder ProductionOrder { get; set; }
    }
}
