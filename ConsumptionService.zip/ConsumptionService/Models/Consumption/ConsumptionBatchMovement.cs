﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsumptionService.Models.Consumption
{
   public class ConsumptionBatchMovement
    {
        public int ConsumptionBatchMovementId { get; set; }
        public int BatchCorrelationId { get; set; }
        public int? ProductionOrderId { get; set; }
 
        public string NotificationId { get; set; }
        public string NotificationType { get; set; }
 
        /// <summary>Chave da notificação de origem — evita gravar o mesmo consumo duas vezes.</summary>
        public string MessageIdempotencyKey { get; set; }
 
        public string MaterialId { get; set; }
        public string MaterialLotId { get; set; }
        public decimal Quantity { get; set; }
        public string Uom { get; set; }
 
        public string RopContId { get; set; }
        public int ActivationCounter { get; set; }
 
        public DateTime EventTime { get; set; }
 
        public bool SentToSap { get; set; }
        public DateTime? SentAt { get; set; }
 
        /// Operação abortada: o consumo deve ser ignorado.
        public bool Discarded { get; set; }
 
        public BatchCorrelation BatchCorrelation { get; set; }
        public ProductionOrder ProductionOrder { get; set; }
    }
}
