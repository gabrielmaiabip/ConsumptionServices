﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsumptionService.Models.Consumption
{
    public class BatchCorrelation
    {
        public BatchCorrelation()
        {
            Movements = new List<ConsumptionBatchMovement>();
            Messages = new List<MessageBacklog>();
        }

        public int BatchCorrelationId { get; set; }
        public int? ProductionOrderId { get; set; }

        /// Identificador técnico único gerado pelo Simatic Batch (ex: 9/1/SB8_3121...).
        public string BatchHandle { get; set; }
        public string BatchName { get; set; }
        public string EntryId { get; set; }

        /// Equipamento/reator em que a batelada está rodando.
        public string EquipmentId { get; set; }
        public string OrderName { get; set; }

        public ProductionOrder ProductionOrder { get; set; }
        public ICollection<ConsumptionBatchMovement> Movements { get; set; }
        public ICollection<MessageBacklog> Messages { get; set; }
    }
}
