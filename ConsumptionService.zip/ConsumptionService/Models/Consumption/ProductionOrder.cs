﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsumptionService.Models.Consumption
{
    public class ProductionOrder
    {
        /// Cadastro mestre da ordem de produção vinda do SAP.
        /// Uma ordem pode ser executada em vários lotes físicos (BatchCorrelation).

        public ProductionOrder()
        {
            PlannedMaterials = new List<PlannedMaterial>();
            Correlations = new List<BatchCorrelation>();
        }

        public int ProductionOrderId { get; set; }

        /// Nome da ordem (geralmente ERP ID + Production ID). Chave natural vinda do SAP.
        public string OrderName { get; set; }
        public string OrderCategoryName { get; set; }
        public string BatchName { get; set; }
        public string BatchHandle { get; set; }
        public string RecipeProcedureName { get; set; }
        public decimal PlannedQuantity { get; set; }
        public string PlannedUom { get; set; }
        public string CurrentState { get; set; }
        public DateTime CreatedAt { get; set; }

        public ICollection<PlannedMaterial> PlannedMaterials { get; set; }
        public ICollection<BatchCorrelation> Correlations { get; set; }
    }
}
