﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace ConsumptionService.Models.B2mml
{
    public static class B2mmlNamespace
    {
        public const string Uri = "http://www.wbf.org/xml/b2mml-v02";
    }

    [XmlRoot("ProductionPerformance", Namespace = B2mmlNamespace.Uri)]
    public class ProductionPerformance
    {
        [XmlElement("ID", Namespace = B2mmlNamespace.Uri)]
        public string Id { get; set; }

        [XmlElement("PublishedDate", Namespace = B2mmlNamespace.Uri)]
        public DateTime PublishedDate { get; set; }

        [XmlElement("ProductionResponse", Namespace = B2mmlNamespace.Uri)]
        public ProductionResponse ProductionResponse { get; set; }
    }

    public class ProductionResponse
    {
        [XmlElement("ID", Namespace = B2mmlNamespace.Uri)]
        public string Id { get; set; }

        [XmlElement("SegmentResponse", Namespace = B2mmlNamespace.Uri)]
        public SegmentResponse SegmentResponse { get; set; }
    }

    public class SegmentResponse
    {
        [XmlElement("ID", Namespace = B2mmlNamespace.Uri)]
        public string Id { get; set; }

        [XmlElement("Description", Namespace = B2mmlNamespace.Uri)]
        public string Description { get; set; }

        [XmlElement("ActualStartTime", Namespace = B2mmlNamespace.Uri)]
        public DateTime ActualStartTime { get; set; }

        [XmlElement("ActualEndTime", Namespace = B2mmlNamespace.Uri)]
        public DateTime ActualEndTime { get; set; }

        [XmlElement("MaterialConsumedActual", Namespace = B2mmlNamespace.Uri)]
        public List<MaterialConsumedActual> MaterialConsumedActual { get; set; }

        public SegmentResponse()
        {
            MaterialConsumedActual = new List<MaterialConsumedActual>();
        }
    }

    public class MaterialConsumedActual
    {
        [XmlElement("MaterialDefinitionID", Namespace = B2mmlNamespace.Uri)]
        public string MaterialDefinitionId { get; set; }

        [XmlElement("MaterialLotID", Namespace = B2mmlNamespace.Uri)]
        public string MaterialLotId { get; set; }

        [XmlElement("MaterialSubLotID", Namespace = B2mmlNamespace.Uri)]
        public string MaterialSubLotId { get; set; }

        [XmlElement("Description", Namespace = B2mmlNamespace.Uri)]
        public string Description { get; set; }

        [XmlElement("Location", Namespace = B2mmlNamespace.Uri)]
        public Location Location { get; set; }

        [XmlElement("Quantity", Namespace = B2mmlNamespace.Uri)]
        public Quantity Quantity { get; set; }
    }

    public class Location
    {
        [XmlElement("EquipmentID", Namespace = B2mmlNamespace.Uri)]
        public string EquipmentId { get; set; }

        [XmlElement("EquipmentElementLevel", Namespace = B2mmlNamespace.Uri)]
        public string EquipmentElementLevel { get; set; }

        [XmlElement("Location", Namespace = B2mmlNamespace.Uri)]
        public Location NestedLocation { get; set; }
    }

    public class Quantity
    {
        [XmlElement("QuantityString", Namespace = B2mmlNamespace.Uri)]
        public string QuantityString { get; set; }

        [XmlElement("DataType", Namespace = B2mmlNamespace.Uri)]
        public string DataType { get; set; }

        [XmlElement("UnitOfMeasure", Namespace = B2mmlNamespace.Uri)]
        public string UnitOfMeasure { get; set; }
    }
}

