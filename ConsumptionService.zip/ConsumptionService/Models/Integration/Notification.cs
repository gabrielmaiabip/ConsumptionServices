﻿namespace ConsumptionService.Models.Integration
{
    /// <summary>
    /// Espelho (somente leitura) da tabela [Notification] do banco do BIL (SIMATIC IT).
    /// O serviço NUNCA escreve nesta base — apenas lê as notificações do MES.
    /// </summary>
    public partial class Notification
    {
        public int Id { get; set; }
        public string NotificationCode { get; set; }
        public string EventId { get; set; }

        public string NotificationType { get; set; }

        public string NotificationDetail { get; set; }

        public string ReceivedTime { get; set; }
        public string StoredTime { get; set; }
        public string ConsumedTime { get; set; }
        public int State { get; set; }
        public string PCellHandle { get; set; }

        public virtual NotificationData NotificationData { get; set; }
    }
}

