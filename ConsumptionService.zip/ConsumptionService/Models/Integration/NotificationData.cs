﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsumptionService.Models.Integration
{
    public partial class NotificationData
    {
        public int NotificationId { get; set; }
        public string InternalData { get; set; }
        public string SourceData { get; set; }

        public virtual Notification Notification { get; set; }
    }
}
