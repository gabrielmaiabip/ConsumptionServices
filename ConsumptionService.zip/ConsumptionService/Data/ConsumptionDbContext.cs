﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Data.Entity.Infrastructure.Annotations;

namespace ConsumptionService.Data
{
    using ConsumptionService.Models.Consumption;

    public class ConsumptionDbContext : DbContext
    {
        static ConsumptionDbContext()
        {
            Database.SetInitializer<ConsumptionDbContext>(null);
        }

        public ConsumptionDbContext()
            : base("name=ConsumptionDB")
        {
        }

        public ConsumptionDbContext(string nameOrConnectionString)
            : base(nameOrConnectionString)
        {
        }

        public DbSet<ProductionOrder> ProductionOrders { get; set; }
        public DbSet<PlannedMaterial> PlannedMaterials { get; set; }
        public DbSet<BatchCorrelation> BatchCorrelations { get; set; }
        public DbSet<ConsumptionBatchMovement> ConsumptionBatchMovements { get; set; }
        public DbSet<MessageBacklog> MessageBacklogs { get; set; }
        public DbSet<ProcessedNotification> ProcessedNotifications { get; set; }
        public DbSet<MaterialStorageLocation> MaterialStorageLocations { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<MaterialStorageLocation>().ToTable("MaterialStorageLocation");
            modelBuilder.Entity<MaterialStorageLocation>().HasKey(e => e.MaterialId);
            modelBuilder.Entity<MaterialStorageLocation>().Property(e => e.MaterialId).HasMaxLength(120).IsRequired();
            modelBuilder.Entity<MaterialStorageLocation>().Property(e => e.StorageLocation).HasMaxLength(120).IsRequired();

            modelBuilder.Entity<ProductionOrder>().ToTable("ProductionOrder");
            modelBuilder.Entity<ProductionOrder>().HasKey(e => e.ProductionOrderId);
            modelBuilder.Entity<ProductionOrder>()
                .Property(e => e.OrderName)
                .HasMaxLength(120)
                .IsRequired()
                .HasColumnAnnotation("Index",
                    new IndexAnnotation(new IndexAttribute("UX_ProductionOrder_OrderName") { IsUnique = true }));
            modelBuilder.Entity<ProductionOrder>().Property(e => e.OrderCategoryName).HasMaxLength(120);
            modelBuilder.Entity<ProductionOrder>().Property(e => e.BatchName).HasMaxLength(120);
            modelBuilder.Entity<ProductionOrder>().Property(e => e.BatchHandle).HasMaxLength(120);
            modelBuilder.Entity<ProductionOrder>().Property(e => e.RecipeProcedureName).HasMaxLength(200);
            modelBuilder.Entity<ProductionOrder>().Property(e => e.PlannedQuantity).HasPrecision(18, 6);
            modelBuilder.Entity<ProductionOrder>().Property(e => e.PlannedUom).HasMaxLength(20);
            modelBuilder.Entity<ProductionOrder>().Property(e => e.CurrentState).HasMaxLength(80);

            modelBuilder.Entity<PlannedMaterial>().ToTable("PlannedMaterial");
            modelBuilder.Entity<PlannedMaterial>().HasKey(e => e.PlannedMaterialId);
            modelBuilder.Entity<PlannedMaterial>().Property(e => e.MaterialId).HasMaxLength(120).IsRequired();
            modelBuilder.Entity<PlannedMaterial>().Property(e => e.MaterialDescription).HasMaxLength(200);
            modelBuilder.Entity<PlannedMaterial>().Property(e => e.PlannedQuantity).HasPrecision(18, 6);
            modelBuilder.Entity<PlannedMaterial>().Property(e => e.Uom).HasMaxLength(20);
            modelBuilder.Entity<PlannedMaterial>().Property(e => e.BomItem).HasMaxLength(40);
            modelBuilder.Entity<PlannedMaterial>()
                .HasRequired(m => m.ProductionOrder)
                .WithMany(o => o.PlannedMaterials)
                .HasForeignKey(m => m.ProductionOrderId)
                .WillCascadeOnDelete(true);

            modelBuilder.Entity<BatchCorrelation>().ToTable("BatchCorrelation");
            modelBuilder.Entity<BatchCorrelation>().HasKey(e => e.BatchCorrelationId);
            modelBuilder.Entity<BatchCorrelation>().Property(e => e.BatchHandle).HasMaxLength(120);
            modelBuilder.Entity<BatchCorrelation>().Property(e => e.BatchName).HasMaxLength(120);
            modelBuilder.Entity<BatchCorrelation>().Property(e => e.EntryId).HasMaxLength(120);
            modelBuilder.Entity<BatchCorrelation>().Property(e => e.EquipmentId).HasMaxLength(120);
            modelBuilder.Entity<BatchCorrelation>().Property(e => e.OrderName).HasMaxLength(120);
            modelBuilder.Entity<BatchCorrelation>()
                .HasOptional(c => c.ProductionOrder)
                .WithMany(o => o.Correlations)
                .HasForeignKey(c => c.ProductionOrderId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<ConsumptionBatchMovement>().ToTable("ConsumptionBatchMovement");
            modelBuilder.Entity<ConsumptionBatchMovement>().HasKey(e => e.ConsumptionBatchMovementId);
            modelBuilder.Entity<ConsumptionBatchMovement>().Property(e => e.NotificationId).HasMaxLength(120);
            modelBuilder.Entity<ConsumptionBatchMovement>().Property(e => e.NotificationType).HasMaxLength(80);
            modelBuilder.Entity<ConsumptionBatchMovement>().Property(e => e.RopContId).HasMaxLength(40);
            modelBuilder.Entity<ConsumptionBatchMovement>().Property(e => e.MaterialLotId).HasMaxLength(120);
            modelBuilder.Entity<ConsumptionBatchMovement>().Property(e => e.Uom).HasMaxLength(20);
            modelBuilder.Entity<ConsumptionBatchMovement>().Property(e => e.Quantity).HasPrecision(18, 6).IsRequired();
            modelBuilder.Entity<ConsumptionBatchMovement>().Property(e => e.SentToSap).IsRequired();
            modelBuilder.Entity<ConsumptionBatchMovement>().Property(e => e.Discarded).IsRequired();
            modelBuilder.Entity<ConsumptionBatchMovement>()
                .Property(e => e.MessageIdempotencyKey)
                .HasMaxLength(200)
                .IsRequired()
                .HasColumnAnnotation("Index",
                    new IndexAnnotation(new IndexAttribute("UX_Movement_Idem_Material", 1) { IsUnique = true }));
            modelBuilder.Entity<ConsumptionBatchMovement>()
                .Property(e => e.MaterialId)
                .HasMaxLength(120)
                .IsRequired()
                .HasColumnAnnotation("Index",
                    new IndexAnnotation(new IndexAttribute("UX_Movement_Idem_Material", 2) { IsUnique = true }));
            modelBuilder.Entity<ConsumptionBatchMovement>()
                .HasRequired(m => m.BatchCorrelation)
                .WithMany(c => c.Movements)
                .HasForeignKey(m => m.BatchCorrelationId)
                .WillCascadeOnDelete(true);
            modelBuilder.Entity<ConsumptionBatchMovement>()
                .HasOptional(m => m.ProductionOrder)
                .WithMany()
                .HasForeignKey(m => m.ProductionOrderId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<MessageBacklog>().ToTable("MessageBacklog");
            modelBuilder.Entity<MessageBacklog>().HasKey(e => e.MessageBacklogId);
            modelBuilder.Entity<MessageBacklog>().Property(e => e.RopContId).HasMaxLength(40);
            modelBuilder.Entity<MessageBacklog>().Property(e => e.PayloadXml).IsRequired();
            modelBuilder.Entity<MessageBacklog>().Property(e => e.Status).HasMaxLength(20);
            modelBuilder.Entity<MessageBacklog>().Property(e => e.ErrorMessage).HasMaxLength(1000);
            modelBuilder.Entity<MessageBacklog>()
                .Property(e => e.BacklogKey)
                .HasMaxLength(64)
                .IsRequired()
                .HasColumnAnnotation("Index",
                    new IndexAnnotation(new IndexAttribute("UX_MessageBacklog_BacklogKey") { IsUnique = true }));
            modelBuilder.Entity<MessageBacklog>()
                .HasRequired(mb => mb.BatchCorrelation)
                .WithMany(c => c.Messages)
                .HasForeignKey(mb => mb.BatchCorrelationId)
                .WillCascadeOnDelete(true);
            modelBuilder.Entity<MessageBacklog>()
                .HasOptional(mb => mb.ProductionOrder)
                .WithMany()
                .HasForeignKey(mb => mb.ProductionOrderId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<ProcessedNotification>().ToTable("ProcessedNotification");
            modelBuilder.Entity<ProcessedNotification>().HasKey(e => e.ProcessedNotificationId);
            modelBuilder.Entity<ProcessedNotification>().Property(e => e.SourceSystem).HasMaxLength(80);
            modelBuilder.Entity<ProcessedNotification>().Property(e => e.NotificationId).HasMaxLength(120);
            modelBuilder.Entity<ProcessedNotification>().Property(e => e.NotificationType).HasMaxLength(80);
            modelBuilder.Entity<ProcessedNotification>().Property(e => e.BatchHandle).HasMaxLength(120);
            modelBuilder.Entity<ProcessedNotification>().Property(e => e.OrderName).HasMaxLength(120);
            modelBuilder.Entity<ProcessedNotification>().Property(e => e.RopContId).HasMaxLength(40);
            modelBuilder.Entity<ProcessedNotification>().Property(e => e.ProcessingStatus).HasMaxLength(20);
            modelBuilder.Entity<ProcessedNotification>()
                .Property(e => e.MessageIdempotencyKey)
                .HasMaxLength(200)
                .IsRequired()
                .HasColumnAnnotation("Index",
                    new IndexAnnotation(new IndexAttribute("UX_ProcessedNotification_Idempotency") { IsUnique = true }));
        }
    }
}

