﻿using System.Data.Entity;

namespace ConsumptionService.Data
{
    using ConsumptionService.Models.Integration;

    public partial class SIT_BILEntities : DbContext
    {
        static SIT_BILEntities()
        {
            Database.SetInitializer<SIT_BILEntities>(null);
        }

        public SIT_BILEntities()
            : base("name=SIT_BILEntities")
        {
        }

        public virtual DbSet<Notification> Notifications { get; set; }
        public virtual DbSet<NotificationData> NotificationDatas { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Notification>().ToTable("Notification");
            modelBuilder.Entity<Notification>().HasKey(n => n.Id);
            modelBuilder.Entity<Notification>().Property(n => n.NotificationCode).HasMaxLength(150);
            modelBuilder.Entity<Notification>().Property(n => n.EventId).HasMaxLength(150);
            modelBuilder.Entity<Notification>().Property(n => n.NotificationType).HasMaxLength(30);
            modelBuilder.Entity<Notification>().Property(n => n.NotificationDetail).HasMaxLength(60);
            modelBuilder.Entity<Notification>().Property(n => n.ReceivedTime).HasMaxLength(30);
            modelBuilder.Entity<Notification>().Property(n => n.StoredTime).HasMaxLength(30);
            modelBuilder.Entity<Notification>().Property(n => n.ConsumedTime).HasMaxLength(30);
            modelBuilder.Entity<Notification>().Property(n => n.PCellHandle).HasMaxLength(150);

            modelBuilder.Entity<NotificationData>().ToTable("NotificationData");
            modelBuilder.Entity<NotificationData>().HasKey(nd => nd.NotificationId);
            modelBuilder.Entity<NotificationData>().Property(nd => nd.InternalData).IsRequired();

            modelBuilder.Entity<Notification>()
                .HasOptional(n => n.NotificationData)
                .WithRequired(nd => nd.Notification)
                .WillCascadeOnDelete(false);
        }
    }
}

