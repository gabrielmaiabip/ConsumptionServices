﻿using System;
using System.Diagnostics;
using System.IO;

namespace ConsumptionService.Logging
{
    public static class Log
    {
        private static readonly object _fileLock = new object();
        private const string EventSource = "ConsumptionService";

        private static bool IsDebugMode
        {
            get { return Debugger.IsAttached; }
        }

        private static string GetLogFilePath()
        {
            var now = DateTime.Now;
            var logDir = Path.Combine(
                AppDomain.CurrentDomain.BaseDirectory,
                "Logs",
                now.ToString("yyyy"),
                now.ToString("MM"),
                now.ToString("dd"));

            if (!Directory.Exists(logDir))
                Directory.CreateDirectory(logDir);

            return Path.Combine(logDir, "ConsumptionService.log");
        }

        public static void Info(params object[] messages)
        {
            WriteLog("INFO", messages);
        }

        public static void Trace(params object[] messages)
        {
            WriteLog("TRACE", messages);
        }

        public static void Warn(params object[] messages)
        {
            WriteLog("WARN", messages);
        }

        public static void Error(Exception ex, params object[] messages)
        {
            var msg = string.Join(" | ", messages) + Environment.NewLine + (ex != null ? ex.ToString() : null);
            WriteLog("ERROR", new object[] { msg });
        }

        private static void WriteLog(string level, object[] messages)
        {
            try
            {
                var message = string.Join(" | ", messages);
                var logLine = string.Format("[{0:yyyy-MM-dd HH:mm:ss.fff}] [{1}] {2}", DateTime.Now, level, message);

                if (IsDebugMode)
                {
                    WriteToConsole(level, logLine);
                }
                else
                {
                    lock (_fileLock)
                    {
                        File.AppendAllText(GetLogFilePath(), logLine + Environment.NewLine);
                    }

                    try
                    {
                        using (var eventLog = new EventLog("Application"))
                        {
                            eventLog.Source = EventSource;
                            var eventType = level == "ERROR" ? EventLogEntryType.Error : EventLogEntryType.Information;
                            eventLog.WriteEntry(string.Format("[{0}] {1}", level, message), eventType);
                        }
                    }
                    catch
                    {
                        // Ignora erros do Event Log.
                    }
                }
            }
            catch
            {
                // Fail silently: log nunca deve derrubar o serviço.
            }
        }

        private static void WriteToConsole(string level, string logLine)
        {
            var previousColor = Console.ForegroundColor;
            try
            {
                switch (level)
                {
                    case "ERROR":
                        Console.ForegroundColor = ConsoleColor.Red;
                        break;
                    case "WARN":
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        break;
                    case "TRACE":
                        Console.ForegroundColor = ConsoleColor.DarkGray;
                        break;
                    default:
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        break;
                }
                Console.WriteLine(logLine);
            }
            finally
            {
                Console.ForegroundColor = previousColor;
            }
        }
    }
}

