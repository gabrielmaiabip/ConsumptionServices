﻿using System;
using System.Configuration;
using System.Linq;
using System.Timers;
using ConsumptionService.Data;
using ConsumptionService.Logging;
using ConsumptionService.Services;

namespace ConsumptionService
{
    public class Worker
    {
        private Timer _readerTimer;
        private Timer _dispatcherTimer;
        private readonly object _readerLock = new object();

        private int _timerCycle;
        private int _dispatcherCycle;
        private int _idLastNotification;
        private string _notificationToProcess;

        private readonly BilMessageProcessor _processor = new BilMessageProcessor();
        private readonly SapDispatcher _dispatcher = new SapDispatcher();

        public void Start()
        {
            _timerCycle = ReadIntSetting("TimerCycle", 5);
            _dispatcherCycle = ReadIntSetting("DispatcherCycle", 10);
            _idLastNotification = ReadIntSetting("IdLastNotification", 0);
            _notificationToProcess = ReadStringSetting("NotificationToProcess",
                "OnBatchCreated|OnBatchStateChanged|OnRopStateChanged|OnMoveIn|OnActValRead");

            if (_timerCycle <= 0)
            {
                Log.Warn("TimerCycle inválido (" + _timerCycle + "); Reader não iniciado.");
                return;
            }

            _readerTimer = new Timer { Interval = _timerCycle * 1000 };
            _readerTimer.Elapsed += Reader_Elapsed;
            _readerTimer.Start();

            Log.Info("Reader iniciado (ciclo " + _timerCycle + "s, IdLastNotification > " + _idLastNotification + ").");

            if (_dispatcherCycle > 0)
            {
                _dispatcherTimer = new Timer { Interval = _dispatcherCycle * 1000 };
                _dispatcherTimer.Elapsed += Dispatcher_Elapsed;
                _dispatcherTimer.Start();

                Log.Info("Dispatcher SAP iniciado (ciclo " + _dispatcherCycle + "s).");
            }
            else
            {
                Log.Warn("DispatcherCycle inválido (" + _dispatcherCycle + "); Dispatcher não iniciado.");
            }
        }

        public void Stop()
        {
            if (_readerTimer != null)
            {
                _readerTimer.Stop();
                _readerTimer.Dispose();
                _readerTimer = null;
            }

            if (_dispatcherTimer != null)
            {
                _dispatcherTimer.Stop();
                _dispatcherTimer.Dispose();
                _dispatcherTimer = null;
            }

            Log.Info("Monitoramento BIL e Dispatcher SAP finalizados.");
        }

        public void RunOnce()
        {
            Reader_Elapsed(null, null);
        }

        public void DispatchOnce()
        {
            _dispatcher.Dispatch();
        }

        private void Dispatcher_Elapsed(object sender, ElapsedEventArgs e)
        {
            _dispatcher.Dispatch();
        }

        private void Reader_Elapsed(object sender, ElapsedEventArgs e)
        {
            if (!System.Threading.Monitor.TryEnter(_readerLock))
            {
                Log.Trace("Reader: ciclo anterior ainda em execução, ignorando.");
                return;
            }

            if (_readerTimer != null) _readerTimer.Stop();

            try
            {
                int lastProcessedId = _idLastNotification;

                using (var context = new SIT_BILEntities())
                {
                    var notifications = (from n in context.Notifications
                                         join d in context.NotificationDatas on n.Id equals d.NotificationId
                                         where n.Id > _idLastNotification
                                         orderby n.Id
                                         select new
                                         {
                                             n.Id,
                                             Type = n.NotificationType,
                                             Detail = n.NotificationDetail,
                                             Xml = d.InternalData
                                         }).ToList();

                    foreach (var notification in notifications)
                    {
                        if (string.Equals(notification.Type, "Notification", StringComparison.OrdinalIgnoreCase)
                            && ShouldProcess(notification.Detail))
                        {
                            _processor.Process(notification.Id, notification.Type, notification.Detail, notification.Xml);
                        }

                        lastProcessedId = notification.Id;
                    }
                }

                if (lastProcessedId != _idLastNotification)
                {
                    _idLastNotification = lastProcessedId;
                    SaveLastNotificationCheckpoint(_idLastNotification);
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Reader_Elapsed");
            }
            finally
            {
                if (_readerTimer != null) _readerTimer.Start();
                System.Threading.Monitor.Exit(_readerLock);
            }
        }

        private bool ShouldProcess(string detail)
        {
            if (string.IsNullOrWhiteSpace(detail) || string.IsNullOrWhiteSpace(_notificationToProcess))
                return false;

            return _notificationToProcess
                .Split('|')
                .Any(item => string.Equals(item.Trim(), detail, StringComparison.OrdinalIgnoreCase));
        }

        private void SaveLastNotificationCheckpoint(int id)
        {
            try
            {
                var config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                if (config.AppSettings.Settings["IdLastNotification"] == null)
                    config.AppSettings.Settings.Add("IdLastNotification", id.ToString());
                else
                    config.AppSettings.Settings["IdLastNotification"].Value = id.ToString();

                config.Save(ConfigurationSaveMode.Modified);
                ConfigurationManager.RefreshSection("appSettings");
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Falha ao salvar checkpoint IdLastNotification=" + id);
            }
        }

        private static int ReadIntSetting(string key, int defaultValue)
        {
            int parsed;
            return int.TryParse(ConfigurationManager.AppSettings[key], out parsed) ? parsed : defaultValue;
        }

        private static string ReadStringSetting(string key, string defaultValue)
        {
            var value = ConfigurationManager.AppSettings[key];
            return string.IsNullOrWhiteSpace(value) ? defaultValue : value;
        }
    }
}


