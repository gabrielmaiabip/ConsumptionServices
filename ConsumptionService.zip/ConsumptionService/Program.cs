﻿using System;
using System.ServiceProcess;
using System.Threading;
using ConsumptionService.Service;

namespace ConsumptionService
{
    /// <summary>
    /// Ponto de entrada. Executa como aplicação console quando iniciado
    /// interativamente (depuração no Visual Studio) e como Windows Service quando
    /// iniciado pelo SCM (Service Control Manager).
    /// </summary>
    internal static class Program
    {
        private static void Main(string[] args)
        {
            if (Environment.UserInteractive)
            {
                RunAsConsole();
            }
            else
            {
                ServiceBase.Run(new ConsumptionWindowsService());
            }
        }

        private static void RunAsConsole()
        {
            Console.WriteLine("ConsumptionService (.NET Framework 4.6.2) - modo console");

            var worker = new Worker();
            worker.Start();

            // Quando a entrada padrão não está disponível (ex.: VS hosting process /
            // vshost.exe), Console.ReadLine() retorna imediatamente e encerraria o app.
            // Nesse caso mantemos o processo vivo até Ctrl+C; senão, esperamos ENTER.
            if (Console.IsInputRedirected)
            {
                Console.WriteLine("Monitor do BIL + Dispatcher SAP em execucao. Pressione Ctrl+C para encerrar...");

                var stop = new ManualResetEvent(false);
                Console.CancelKeyPress += (s, e) =>
                {
                    e.Cancel = true;
                    stop.Set();
                };
                stop.WaitOne();
            }
            else
            {
                Console.WriteLine("Monitor do BIL + Dispatcher SAP em execucao. Pressione ENTER para encerrar...");
                Console.ReadLine();
            }

            worker.Stop();
        }
    }
}


