﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using ConsumptionService.Data;
using ConsumptionService.Logging;
using ConsumptionService.Models.B2mml;
using ConsumptionService.Models.Consumption;

namespace ConsumptionService.Services
{
    public class SapDispatcher
    {
        private readonly object _dispatchLock = new object();

        public void Dispatch()
        {
            if (!Monitor.TryEnter(_dispatchLock))
            {
                Log.Trace("Dispatcher: ciclo anterior ainda em execução, ignorando.");
                return;
            }

            try
            {
                using (var context = new ConsumptionDbContext())
                {
                    var quietSeconds = ReadIntSetting("DispatchQuietSeconds", 60);
                    var threshold = DateTime.UtcNow.AddSeconds(-quietSeconds);

                    var pending = context.ConsumptionBatchMovements
                        .Include(m => m.BatchCorrelation)
                        .Where(m => !m.SentToSap && !m.Discarded)
                        .ToList();

                    if (pending.Count == 0) return;

                    var groups = pending
                        .GroupBy(m => new { m.BatchCorrelationId, m.RopContId, m.ActivationCounter })
                        .ToList();

                    Log.Trace("Dispatcher: " + groups.Count + " grupo(s) de ROP pendente(s).");

                    foreach (var group in groups)
                    {
                        var items = group.ToList();

                        var lastEvent = items.Max(m => m.EventTime);
                        if (lastEvent > threshold) continue;

                        DispatchGroup(context, group.Key.BatchCorrelationId, group.Key.RopContId, group.Key.ActivationCounter, items);
                    }

                    ResendFailedBacklogs(context);
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Dispatcher_Elapsed");
            }
            finally
            {
                Monitor.Exit(_dispatchLock);
            }
        }

        private void ResendFailedBacklogs(ConsumptionDbContext context)
        {
            var maxAttempts = ReadIntSetting("DispatchMaxAttempts", 5);

            var failed = context.MessageBacklogs
                .Include(b => b.BatchCorrelation)
                .Where(b => b.Status == "Failed" && b.AttemptCount < maxAttempts)
                .ToList();

            if (failed.Count == 0) return;

            Log.Trace("Dispatcher: reenviando " + failed.Count + " pacote(s) com falha.");

            foreach (var backlog in failed)
            {
                var erpId = ErpIdFromOrderName(backlog.BatchCorrelation != null ? backlog.BatchCorrelation.OrderName : null);
                try
                {
                    DeliverToFileSystem(backlog.PayloadXml, erpId, backlog.BacklogKey);

                    backlog.Status = "Sent";
                    backlog.SentAt = DateTime.UtcNow;
                    backlog.AttemptCount = backlog.AttemptCount + 1;
                    backlog.ErrorMessage = null;

                    var correlationId = backlog.BatchCorrelationId;
                    var ropContId = backlog.RopContId;
                    var activationCounter = backlog.ActivationCounter;
                    var now = DateTime.UtcNow;

                    var groupItems = context.ConsumptionBatchMovements
                        .Where(m => m.BatchCorrelationId == correlationId
                                    && m.RopContId == ropContId
                                    && m.ActivationCounter == activationCounter
                                    && !m.SentToSap && !m.Discarded)
                        .ToList();

                    foreach (var m in groupItems)
                    {
                        m.SentToSap = true;
                        m.SentAt = now;
                    }

                    context.SaveChanges();

                    Log.Info("Reenvio bem-sucedido. BacklogKey=" + backlog.BacklogKey + " Tentativa=" + backlog.AttemptCount);
                }
                catch (Exception ex)
                {
                    backlog.AttemptCount = backlog.AttemptCount + 1;
                    backlog.ErrorMessage = Truncate(ex.Message, 1000);
                    context.SaveChanges();

                    Log.Error(ex, "Reenvio falhou. BacklogKey=" + backlog.BacklogKey + " Tentativa=" + backlog.AttemptCount);
                }
            }
        }

        private void DispatchGroup(ConsumptionDbContext context, int batchCorrelationId, string ropContId, int activationCounter, List<ConsumptionBatchMovement> items)
        {
            var correlation = items[0].BatchCorrelation;
            var orderName = correlation != null ? correlation.OrderName : null;
            var erpId = ErpIdFromOrderName(orderName);

            try
            {
                var performance = BuildPerformance(context, erpId, ropContId, activationCounter, correlation, items);
                var payload = B2mmlWriter.Serialize(performance);

                var backlog = new MessageBacklog
                {
                    BatchCorrelationId = batchCorrelationId,
                    ProductionOrderId = correlation != null ? correlation.ProductionOrderId : (int?)null,
                    RopContId = ropContId,
                    ActivationCounter = activationCounter,
                    BacklogKey = Guid.NewGuid().ToString("N"),
                    PayloadXml = payload,
                    ItemCount = items.Count,
                    Status = "Pending",
                    AttemptCount = 0
                };
                context.MessageBacklogs.Add(backlog);
                context.SaveChanges();

                try
                {
                    DeliverToFileSystem(payload, erpId, backlog.BacklogKey);

                    backlog.Status = "Sent";
                    backlog.SentAt = DateTime.UtcNow;
                    backlog.AttemptCount = 1;

                    var now = DateTime.UtcNow;
                    foreach (var m in items)
                    {
                        m.SentToSap = true;
                        m.SentAt = now;
                    }

                    context.SaveChanges();

                    Log.Info("Pacote ROP enviado. ROP=" + ropContId + " Counter=" + activationCounter +
                             " Itens=" + items.Count + " BacklogKey=" + backlog.BacklogKey);
                }
                catch (Exception exDeliver)
                {
                    backlog.Status = "Failed";
                    backlog.AttemptCount = backlog.AttemptCount + 1;
                    backlog.ErrorMessage = Truncate(exDeliver.Message, 1000);
                    context.SaveChanges();

                    Log.Error(exDeliver, "Dispatcher falha ao entregar BacklogKey=" + backlog.BacklogKey);
                }
            }
            catch (Exception exGroup)
            {
                Log.Error(exGroup, "Dispatcher erro no grupo ROP=" + ropContId);
            }
        }

        private ProductionPerformance BuildPerformance(ConsumptionDbContext context, string erpId, string ropContId, int activationCounter, BatchCorrelation correlation, List<ConsumptionBatchMovement> items)
        {
            var invariant = CultureInfo.InvariantCulture;
            var plantId = ReadStringSetting("B2mmlPlantId", "3000");
            var equipmentId = correlation != null ? correlation.EquipmentId : null;

            var segment = new SegmentResponse
            {
                Id = ropContId,
                Description = activationCounter.ToString(invariant),
                ActualStartTime = items.Min(m => m.EventTime),
                ActualEndTime = items.Max(m => m.EventTime)
            };

            foreach (var movement in items)
            {
                var storageLocation = LookupStorageLocation(context, movement.MaterialId);

                segment.MaterialConsumedActual.Add(new MaterialConsumedActual
                {
                    MaterialDefinitionId = movement.MaterialId,
                    MaterialLotId = movement.MaterialLotId ?? string.Empty,
                    MaterialSubLotId = string.Empty,
                    Description = string.Empty,
                    Location = new Location
                    {
                        EquipmentId = plantId,
                        EquipmentElementLevel = "Site",
                        NestedLocation = new Location
                        {
                            EquipmentId = storageLocation,
                            EquipmentElementLevel = "StorageLocation",
                            NestedLocation = string.IsNullOrWhiteSpace(equipmentId) ? null : new Location
                            {
                                EquipmentId = equipmentId,
                                EquipmentElementLevel = "Unit"
                            }
                        }
                    },
                    Quantity = new Quantity
                    {
                        QuantityString = movement.Quantity.ToString(invariant),
                        DataType = "float",
                        UnitOfMeasure = string.IsNullOrWhiteSpace(movement.Uom) ? "KG" : movement.Uom.Trim().ToUpperInvariant()
                    }
                });
            }

            return new ProductionPerformance
            {
                Id = Guid.NewGuid().ToString("N"),
                PublishedDate = DateTime.Now,
                ProductionResponse = new ProductionResponse
                {
                    Id = string.IsNullOrWhiteSpace(erpId) ? orDefault(correlation) : erpId,
                    SegmentResponse = segment
                }
            };
        }

        private static string orDefault(BatchCorrelation correlation)
        {
            return correlation != null ? correlation.OrderName : string.Empty;
        }

        private string LookupStorageLocation(ConsumptionDbContext context, string materialId)
        {
            var mapping = context.MaterialStorageLocations.FirstOrDefault(m => m.MaterialId == materialId);
            return (mapping != null ? mapping.StorageLocation : null) ?? ReadStringSetting("DefaultStorageLocation", "2102");
        }

        private void DeliverToFileSystem(string payload, string erpId, string backlogKey)
        {
            var directory = ReadStringSetting("DisDropFolder", string.Empty);
            if (string.IsNullOrWhiteSpace(directory))
                throw new InvalidOperationException("DisDropFolder não configurado no App.config.");

            if (!Directory.Exists(directory))
                Directory.CreateDirectory(directory);

            var fileName = string.Format(CultureInfo.InvariantCulture,
                "ProductionPerformance_{0}_{1:yyyyMMddHHmmssfff}.xml",
                SanitizeFileName(erpId), DateTime.UtcNow);

            var fullPath = Path.Combine(directory, fileName);
            File.WriteAllText(fullPath, payload, new UTF8Encoding(false));
        }

        // ---------------------------------------------------------------------
        // Helpers
        // ---------------------------------------------------------------------

        /// <summary>Extrai o ERP ID do OrderName (parte antes do primeiro '-').</summary>
        private static string ErpIdFromOrderName(string orderName)
        {
            if (string.IsNullOrWhiteSpace(orderName)) return null;
            return orderName.Split('-').FirstOrDefault();
        }

        private static string SanitizeFileName(string input)
        {
            if (string.IsNullOrWhiteSpace(input)) return "UNKNOWN";
            var invalid = Path.GetInvalidFileNameChars();
            return new string(input.Select(c => invalid.Contains(c) ? '_' : c).ToArray());
        }

        private static string Truncate(string input, int maxLength)
        {
            if (string.IsNullOrEmpty(input)) return input;
            return input.Length <= maxLength ? input : input.Substring(0, maxLength);
        }

        private static int ReadIntSetting(string key, int defaultValue)
        {
            int parsed;
            return int.TryParse(ConfigurationManager.AppSettings[key], out parsed) ? parsed : defaultValue;
        }

        private static string ReadStringSetting(string key, string defaultValue)
        {
            var value = ConfigurationManager.AppSettings[key];
            return string.IsNullOrWhiteSpace(value) ? defaultValue : value;
        }
    }
}

