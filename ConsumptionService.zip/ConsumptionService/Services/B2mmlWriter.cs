﻿using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using ConsumptionService.Models.B2mml;

namespace ConsumptionService.Services
{
    public static class B2mmlWriter
    {
        public static string Serialize(ProductionPerformance performance)
        {
            var serializer = new XmlSerializer(typeof(ProductionPerformance));

            var namespaces = new XmlSerializerNamespaces();
            namespaces.Add("bml", B2mmlNamespace.Uri);

            var settings = new XmlWriterSettings
            {
                Indent = true,
                Encoding = new UTF8Encoding(false), 
                OmitXmlDeclaration = false
            };

            using (var memory = new MemoryStream())
            {
                using (var xmlWriter = XmlWriter.Create(memory, settings))
                {
                    serializer.Serialize(xmlWriter, performance, namespaces);
                }

                return settings.Encoding.GetString(memory.ToArray());
            }
        }
    }
}

