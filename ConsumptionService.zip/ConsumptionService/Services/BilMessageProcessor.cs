﻿using System;
using System.Linq;
using ConsumptionService.Data;
using ConsumptionService.Logging;
using ConsumptionService.Models.Consumption;
using ConsumptionService.Parsing;

namespace ConsumptionService.Services
{
   
    public class BilMessageProcessor
    {
        private const string MaterialBatchParameter = "SP_MaterialBatch";

        public void Process(int notificationId, string notificationType, string detail, string xml)
        {
            Log.Info("Processando notificação BIL - Id " + notificationId + " (" + detail + ")");

            var message = NotificationXmlParser.Parse(xml);
            if (message == null)
            {
                Log.Warn("Notificação " + notificationId + " ignorada: XML inválido ou sem <Message>.");
                return;
            }

            var idempotencyKey = !string.IsNullOrWhiteSpace(message.MessageId)
                ? message.MessageId
                : detail + ":" + notificationId;

            try
            {
                using (var context = new ConsumptionDbContext())
                {
                    if (IsAlreadyProcessed(context, idempotencyKey))
                    {
                        Log.Trace("Notificação já processada, ignorando. Idem=" + idempotencyKey);
                        return;
                    }

                    var status = "PROCESSED";
                    try
                    {
                        switch (detail)
                        {
                            case "OnBatchCreated":
                                CreateOrderCorrelation(context, message);
                                break;
                            case "OnBatchStateChanged":
                                ProcessOnBatchStateChanged(context, message);
                                break;
                            case "OnMoveIn":
                                ProcessOnMoveIn(context, message, notificationId, idempotencyKey);
                                break;
                            default:
                                status = "IGNORED";
                                break;
                        }
                    }
                    catch (Exception exDetail)
                    {
                        status = "ERROR";
                        Log.Error(exDetail, "Erro processando detail=" + detail + " Id=" + notificationId);
                    }

                    RecordProcessedNotification(context, message, detail, idempotencyKey, status, notificationId);
                    context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Falha ao persistir notificação. Idem=" + idempotencyKey);
            }
        }

        private void CreateOrderCorrelation(ConsumptionDbContext context, BilMessage message)
        {
            var order = GetOrCreateProductionOrder(context, message);

            if (order != null && !context.PlannedMaterials.Any(p => p.ProductionOrderId == order.ProductionOrderId))
            {
                foreach (var param in message.Parameters)
                {
                    if (!param.IsInputMaterial) continue;

                    var materialCode = param.MaterialCode;
                    if (string.IsNullOrWhiteSpace(materialCode)) continue;

                    context.PlannedMaterials.Add(new PlannedMaterial
                    {
                        ProductionOrderId = order.ProductionOrderId,
                        MaterialId = materialCode,
                        MaterialDescription = param.MaterialName,
                        PlannedQuantity = ParseUtil.ParseDecimal(param.SetPoint),
                        Uom = param.UomName,
                        BomItem = param.ParameterId
                    });
                }
            }

            GetOrCreateCorrelation(context, message, order != null ? order.ProductionOrderId : (int?)null);
            context.SaveChanges();
        }

        /// OnBatchStateChanged: atualiza o estado da ordem. Se o batch foi abortado em
        /// execução (RUNNING -> ABORTED), descarta os consumos ainda não enviados ao SAP.
        private void ProcessOnBatchStateChanged(ConsumptionDbContext context, BilMessage message)
        {
            var entryId = message.BatchName;
            var oldState = message.OldState ?? string.Empty;
            var currentState = message.CurrentState ?? string.Empty;

            var correlation = context.BatchCorrelations.FirstOrDefault(b => b.EntryId == entryId);
            if (correlation == null) return;

            if (correlation.ProductionOrderId.HasValue)
            {
                var orderId = correlation.ProductionOrderId.Value;
                var order = context.ProductionOrders.FirstOrDefault(o => o.ProductionOrderId == orderId);
                if (order != null) order.CurrentState = currentState;
            }

            if (currentState.IndexOf("ABORTED", StringComparison.OrdinalIgnoreCase) >= 0 &&
                oldState.IndexOf("RUNNING", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                var correlationId = correlation.BatchCorrelationId;
                var pending = context.ConsumptionBatchMovements
                    .Where(m => m.BatchCorrelationId == correlationId && !m.SentToSap)
                    .ToList();

                foreach (var m in pending) m.Discarded = true;

                Log.Info("Batch abortado, " + pending.Count + " consumo(s) descartado(s). EntryId=" + entryId);
            }

            context.SaveChanges();
        }

        /// OnMoveIn: registra o consumo real de cada material de entrada, carimbando
        /// etapa (RopContId) e tentativa (ActivationCounter) para agrupamento posterior.
        private void ProcessOnMoveIn(ConsumptionDbContext context, BilMessage message, int sourceMessageId, string idempotencyKey)
        {
            if (message.Parameters.Count == 0) return;

            var order = GetOrCreateProductionOrder(context, message);
            var correlation = GetOrCreateCorrelation(context, message, order != null ? order.ProductionOrderId : (int?)null);
            context.SaveChanges();

            var ropContId = message.RopContId;
            var activationCounter = message.RopActivationCounter;
            var eventTime = message.NotificationTime ?? DateTime.UtcNow;

            var batchParam = message.GetParameter(MaterialBatchParameter);
            var materialLotId = batchParam != null ? batchParam.SetPoint : null;

            foreach (var param in message.Parameters)
            {
                if (!param.IsInputMaterial) continue;

                var materialCode = param.MaterialCode;
                if (string.IsNullOrWhiteSpace(materialCode)) continue;

                var alreadyExists = context.ConsumptionBatchMovements
                    .Any(m => m.MessageIdempotencyKey == idempotencyKey && m.MaterialId == materialCode);
                if (alreadyExists) continue;

                context.ConsumptionBatchMovements.Add(new ConsumptionBatchMovement
                {
                    BatchCorrelationId = correlation.BatchCorrelationId,
                    ProductionOrderId = order != null ? order.ProductionOrderId : (int?)null,
                    NotificationId = sourceMessageId.ToString(),
                    NotificationType = "OnMoveIn",
                    MessageIdempotencyKey = idempotencyKey,
                    MaterialId = materialCode,
                    MaterialLotId = materialLotId,
                    Quantity = ParseUtil.ParseDecimal(param.ActualValue),
                    Uom = param.UomName,
                    RopContId = ropContId,
                    ActivationCounter = activationCounter,
                    EventTime = eventTime,
                    SentToSap = false,
                    Discarded = false
                });

                Log.Trace("Consumo persistido: material " + materialCode + " ROP=" + ropContId + " Counter=" + activationCounter);
            }

            context.SaveChanges();
        }

        // ---------------------------------------------------------------------
        // Helpers de domínio
        // ---------------------------------------------------------------------

        private bool IsAlreadyProcessed(ConsumptionDbContext context, string idempotencyKey)
        {
            if (string.IsNullOrWhiteSpace(idempotencyKey)) return false;
            return context.ProcessedNotifications.Any(p => p.MessageIdempotencyKey == idempotencyKey);
        }

        private void RecordProcessedNotification(ConsumptionDbContext context, BilMessage message, string detail, string idempotencyKey, string status, int sourceId)
        {
            context.ProcessedNotifications.Add(new ProcessedNotification
            {
                SourceSystem = "BIL",
                NotificationId = sourceId.ToString(),
                NotificationType = detail,
                MessageIdempotencyKey = idempotencyKey,
                BatchHandle = message.BatchHandle,
                OrderName = message.OrderName,
                RopContId = message.RopContId,
                ProcessingStatus = status,
                ProcessedAt = DateTime.UtcNow
            });
        }

        private ProductionOrder GetOrCreateProductionOrder(ConsumptionDbContext context, BilMessage message)
        {
            var orderName = message.OrderName;
            if (string.IsNullOrWhiteSpace(orderName)) return null;

            var order = context.ProductionOrders.FirstOrDefault(o => o.OrderName == orderName);
            if (order == null)
            {
                order = new ProductionOrder
                {
                    OrderName = orderName,
                    OrderCategoryName = message.OrderCategoryName,
                    BatchName = message.BatchName,
                    BatchHandle = message.BatchHandle,
                    RecipeProcedureName = message.RecipeProcedureName,
                    PlannedQuantity = message.Quantity,
                    PlannedUom = message.UomName,
                    CurrentState = message.CurrentState,
                    CreatedAt = DateTime.UtcNow
                };
                context.ProductionOrders.Add(order);
                context.SaveChanges();
            }

            return order;
        }

        private BatchCorrelation GetOrCreateCorrelation(ConsumptionDbContext context, BilMessage message, int? productionOrderId)
        {
            var entryId = message.BatchName;
            var batchHandle = message.BatchHandle;

            var correlation = context.BatchCorrelations
                .FirstOrDefault(b => b.EntryId == entryId && b.BatchHandle == batchHandle);

            if (correlation == null)
            {
                correlation = new BatchCorrelation
                {
                    ProductionOrderId = productionOrderId,
                    BatchHandle = batchHandle,
                    BatchName = message.BatchName,
                    EntryId = entryId,
                    EquipmentId = message.UnitName,
                    OrderName = message.OrderName
                };
                context.BatchCorrelations.Add(correlation);
                context.SaveChanges();
            }
            else
            {
                if (string.IsNullOrWhiteSpace(correlation.EquipmentId))
                    correlation.EquipmentId = message.UnitName;

                if (!correlation.ProductionOrderId.HasValue && productionOrderId.HasValue)
                    correlation.ProductionOrderId = productionOrderId;
            }

            return correlation;
        }
    }
}

